'use strict';
const conversation = require('../message');
const cloudant = require('../../util/db');
const db = cloudant.db;

let postMessage = (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  let user_key = req.body.user_key;
  let type = req.body.type;
  let content = {
    'text' : req.body.content
  };

  db.get(user_key).then(doc => {
     conversation.getConversationResponse(content, doc.context).then(data => {
       db.insert(Object.assign(doc, {
        'context': Object.assign(data.context, {
          'timezone' : "Asia/Seoul"
        }),
      }));

      return res.json({
        "message" : {
          "text" : getOutputText(data)
        }
      });
    }).catch(function(err){
      return res.json({
          "message" : {
            "text" : JSON.stringify(err.message)
          }
      });
    });
  }).catch(function(err) {
       conversation.getConversationResponse(content, {}).then(data => {
       db.insert({
        '_id' : user_key,
        'user_key' : user_key,
        'context': data.context,
        'type' : 'kakao'
      });
          
      return res.json({
          "message" : {
            "text" : getOutputText(data)
          }
      });   
    }).catch(function(err){
      return res.json({
          "message" : {
            "text" : JSON.stringify(err.message)
          }
      });
    });
    
  });
};

let getOutputText = data => {
  let output = data.output;
  if(output.text && Array.isArray(output.text)){
    return output.text.join('\\n');
  }
  else if(output.text){
    return output.text;
  }
  else return "";
};

module.exports = {
    'initialize': function(app, options) {
        app.post('/api/kakao/message', postMessage);
    }
};