VERSION = (0, 8, 7)
__version__ = '.'.join(map(str, VERSION))
