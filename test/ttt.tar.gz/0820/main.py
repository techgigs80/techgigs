import argparse
import os
import Drain
import pickle
import logging

logger = logging.getLogger()
logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)

DATA_PATH   = './drain/data/was'
OUTPUT_PATH = './drain/result'
LOG_FILE    = 'U11A_11.out'
# LOG_FILE    = 'test2.out'

## meanless expressions & known expressions
pre_list = [
    [r'[\*]{62}\n',             ''],    # ****************
    [r'^[\s]{1}DATE_TIME.*',    ''],    #  DATE_TIME : 2019/06/03 02:14:25
    [r'^[\s]{1}COMMAND.*',      ''],    #  COMMAND   : start
    [r'^[\s]{0,2}JAVA_OPTS.*',  ''],    # JAVA_OPTS line
    [r'[\=]{73}.*',             ''],    # ================
    [r'[\s]{2}JB.*',            ''],    # JBOSS options
    [r'[\s]{2}JAVA:.*',         ''],    # JAVA line
    [r'^[\s]*\n',               ''],    # whole empty line
    [r'^[\#]{3}.*\n',           ''],    # start with ###, something about error of causes
    [r'^[\;].*\n',              ''],    # start with comman, something about error of causes
    [r'^[\s]*at.*\n',           ''],    # start with 'at', something about java method
    [r'^Caused by.*\n',         ''],    # start with 'Cause by', something about error of causes
    [r'^[\s]+[\.]{3}.*\n',      ''],    # ... xx more
    [r'JB[\w]+:',        'JB_CODE'],    # identifier : JB***** code number
    [r'[\(].*[\)] ',     'THREAD '],    # thread name
    [r'', ''],
    [r'', ''],
    [r'', ''],
    [r'', ''],
    [r'', '']
]

## regex for token
regex      = [
    r'[0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3}' , # timestamp
    r'(/|)([0-9]+\.){3}[0-9]+(:[0-9]+|)(:|)', # IP
    r'(?<=[^A-Za-z0-9])(\-?\+?\d+)(?=[^A-Za-z0-9])|[0-9]+$', # Numbers
]

log_format = '<Date> <Level> <Process_name> <Content>'  # U11A_11.out

depth       = 4
st          = 0.5
sim         = 'seqDistOnlyToken'
is_training = True

if is_training:
    logging.info('Bulid parser tree for training')   
    parser = Drain.LogParser(log_format, 
                                indir= DATA_PATH, 
                                outdir= OUTPUT_PATH,  
                                depth= depth, 
                                st= st, 
                                rex= regex,
                                p_list = pre_list, 
                                sim= sim)
else:
    logging.info('Bulid parser tree for test')   
    with open(os.path.join(OUTPUT_PATH,'train_parser.pkl'), 'rb') as f:
        parser = pickle.load(f)

parser.parse(LOG_FILE, is_training=is_training)

print('number of clusters:',len(parser.logCluL))

# save train results
parser.saver(parser.logCluL, is_training= is_training)


# # save as pickle
# if args.is_training:
#     with open(os.path.join(args.output_dir,'train_parser.pkl'), 'wb') as f:
#         pickle.dump(parser,f, protocol=pickle.HIGHEST_PROTOCOL)
