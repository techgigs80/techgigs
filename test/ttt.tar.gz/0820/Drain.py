"""
Description : This file implements the Drain algorithm for log parsing
Author      : LogPAI team
License     : MIT
"""

import re
import os
import numpy as np
import pandas as pd
import hashlib
from datetime import datetime
from tqdm import tqdm
import logging

logger = logging.getLogger()
logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)



class Logcluster:
    def __init__(self, logTemplate='', logIDL=None):
        self.logTemplate = logTemplate
        if logIDL is None:
            logIDL = []
        self.logIDL = logIDL


class Node:
    def __init__(self, childD=None, depth=0, digitOrtoken=None):
        if childD is None:
            childD = dict()
        self.childD = childD
        self.depth = depth
        self.digitOrtoken = digitOrtoken


class LogParser:
    def __init__(self, log_format, indir='./', outdir='./result/', depth=4, st=0.4, 
                 maxChild=100, rex=[], keep_para=True, p_list=[], sim='seqDist', alpha=None):
        """
        Attributes
        ----------
            rex : regular expressions used in preprocessing (step1)
            path : the input path stores the input log file name
            depth : depth of all leaf nodes
            st : similarity threshold
            maxChild : max number of children of an internal node
            logName : the name of the input file containing raw log messages
            savePath : the output path stores the file containing structured logs
        """
        self.path = indir
        self.depth = depth - 2
        self.st = st
        self.maxChild = maxChild
        self.logName = None
        self.savePath = outdir
        self.df_log = None
        self.log_format = log_format
        self.rex = rex
        self.keep_para = keep_para
        self.p_list = p_list
        self.sim = sim
        self.alpha = alpha
    
    def hasNumbers(self, s):
        return any(char.isdigit() for char in s)

    def treeSearch(self, rn, seq):
        retLogClust = None

        seqLen = len(seq)
        if seqLen not in rn.childD:
            return retLogClust
        
        parentn = rn.childD[seqLen]
        currentDepth = 1
        for token in seq:
            if currentDepth >= self.depth or currentDepth > seqLen:
                break

            if token in parentn.childD:
                parentn = parentn.childD[token]
            elif '<*>' in parentn.childD:
                parentn = parentn.childD['<*>']
            else:
                return retLogClust
            
            currentDepth += 1

        logClustL = parentn.childD

        retLogClust = self.fastMatch(logClustL, seq)
        
        return retLogClust

    def addSeqToPrefixTree(self, rn, logClust):
        seqLen = len(logClust.logTemplate)
        if seqLen not in rn.childD:
            firtLayerNode = Node(depth=1, digitOrtoken=seqLen)
            rn.childD[seqLen] = firtLayerNode
        else:
            firtLayerNode = rn.childD[seqLen]

        parentn = firtLayerNode

        currentDepth = 1
        for token in logClust.logTemplate:

            #Add current log cluster to the leaf node
            if currentDepth >= self.depth or currentDepth > seqLen:
                if len(parentn.childD) == 0:
                    parentn.childD = [logClust]
                else:
                    parentn.childD.append(logClust)
                break

            #If token not matched in this layer of existing tree. 
            if token not in parentn.childD:
                if not self.hasNumbers(token):
                    if '<*>' in parentn.childD:
                        if len(parentn.childD) < self.maxChild:
                            newNode = Node(depth=currentDepth + 1, digitOrtoken=token)
                            parentn.childD[token] = newNode
                            parentn = newNode
                        else:
                            parentn = parentn.childD['<*>']
                    else:
                        if len(parentn.childD)+1 < self.maxChild:
                            newNode = Node(depth=currentDepth+1, digitOrtoken=token)
                            parentn.childD[token] = newNode
                            parentn = newNode
                        elif len(parentn.childD)+1 == self.maxChild:
                            newNode = Node(depth=currentDepth+1, digitOrtoken='<*>')
                            parentn.childD['<*>'] = newNode
                            parentn = newNode
                        else:
                            parentn = parentn.childD['<*>']
            
                else:
                    if '<*>' not in parentn.childD:
                        newNode = Node(depth=currentDepth+1, digitOrtoken='<*>')
                        parentn.childD['<*>'] = newNode
                        parentn = newNode
                    else:
                        parentn = parentn.childD['<*>']

            #If the token is matched
            else:
                parentn = parentn.childD[token]

            currentDepth += 1


    #seq1 is template
    def seqDist(self, seq1, seq2):
        assert len(seq1) == len(seq2)
        simTokens = 0
        numOfPar = 0

        for token1, token2 in zip(seq1, seq2):
            if token1 == '<*>':
                numOfPar += 1
                continue
            if token1 == token2:
                simTokens += 1 

        retVal = float(simTokens) / len(seq1)

        return retVal, numOfPar

    def seqDistOnlyToken(self, seq1, seq2):
        assert len(seq1) == len(seq2)
        simTokens = 0
        numOfPar = 0

        counts = 0
        for token1, token2 in zip(seq1, seq2):

            if token1 == '<*>':
                numOfPar += 1
                continue
            else:
                counts+=1

            if token1 == token2:
                simTokens += 1 


        retVal = float(simTokens) / counts

        return retVal, numOfPar

    def seqDistVarCont(self, seq1, seq2, alpha):
        assert len(seq1) == len(seq2)

        simTokens = 0
        numOfPar = 0

        for token1, token2 in zip(seq1, seq2):

            if token1 == '<*>':
                numOfPar += 1
                continue


            if token1 == token2:
                simTokens += 1 


        retVal = (float(simTokens)+alpha*numOfPar) / len(seq1)

        return retVal, numOfPar

    def fastMatch(self, logClustL, seq):
        retLogClust = None

        maxSim = -1
        maxNumOfPara = -1
        maxClust = None

        for logClust in logClustL:
            if self.sim == 'seqDist':
                curSim, curNumOfPara = self.seqDist(logClust.logTemplate, seq)
            elif self.sim == 'seqDistOnlyToken':
                curSim, curNumOfPara = self.seqDistOnlyToken(logClust.logTemplate, seq)
            elif self.sim == 'seqDistVarCont':
                curSim, curNumOfPara = self.seqDistVarCont(logClust.logTemplate, seq, self.alpha)
            else:
                print('non-match proper similar method')

            if curSim>maxSim or (curSim==maxSim and curNumOfPara>maxNumOfPara):
                maxSim = curSim
                maxNumOfPara = curNumOfPara
                maxClust = logClust

        if maxSim >= self.st:
            retLogClust = maxClust  

        return retLogClust

    def getTemplate(self, seq1, seq2, is_training):
        assert len(seq1) == len(seq2)
        retVal = []

        i = 0
        for word in seq1:
            if word == seq2[i]:
                retVal.append(word)
            else:
                if is_training:
                    retVal.append('<*>')
                else:
                    retVal.append(seq2[i])

            i += 1

        return retVal
    

        
        
    def saver(self, logClustL, is_training):
        
        if not os.path.exists(self.savePath):
            os.makedirs(self.savePath)
        
        log_templates = [0] * self.df_log.shape[0]
        log_templateids = [0] * self.df_log.shape[0]
        df_events = []
        for logClust in logClustL:
            logging.info('before: {}'.format(logClust.logTemplate)) 
            template_str = ' '.join(logClust.logTemplate)
            logging.info('after: {}'.format(template_str)) 
            occurrence = len(logClust.logIDL)
            template_id = hashlib.md5(template_str.encode('utf-8')).hexdigest()[0:8]
            
            if is_training:
                IDL = logClust.logIDL
            else:
                # check if there's logIDL
                IDL =set(logClust.logIDL).intersection(self.df_log['LineId'].values)

            for logID in IDL:
                
                logID -= 1
                
                if not is_training:
                    logID -= self.infer_start
                    
                log_templates[logID] = template_str
                log_templateids[logID] = template_id
            df_events.append([template_id, template_str, occurrence])

        df_event = pd.DataFrame(df_events, columns=['EventId', 'EventTemplate', 'Occurrences'])
        self.df_log['EventId'] = log_templateids
        self.df_log['EventTemplate'] = log_templates
        
        if self.keep_para:
            logging.info('Attach ParamsList...')   
            if is_training:
                self.df_log["EventTemplate"], _ , self.df_log["ParameterList"] = zip(*self.df_log.apply(lambda x: self.get_parameter_list(x,is_training), axis=1)) 
            else:
                self.df_log["EventTemplate"], self.df_log["re_Content"], self.df_log["ParameterList"] = zip(*self.df_log.apply(lambda x: self.get_parameter_list(x,is_training), axis=1)) 
        
        # as csv
        logging.info('Saving structured.csv...')   

        self.df_log.to_csv(os.path.join(self.savePath, self.logName + '_structured.csv'), index=False)
        
        # as pkl
        logging.info('Saving structured.pkl...')   

        
        self.df_log.to_pickle(os.path.join(self.savePath, self.logName + '_structured.pkl'))


        occ_dict = dict(self.df_log['EventTemplate'].value_counts())
        df_event = pd.DataFrame()
        df_event['EventTemplate'] = self.df_log['EventTemplate'].unique()
        df_event['EventId'] = df_event['EventTemplate'].map(lambda x: hashlib.md5(x.encode('utf-8')).hexdigest()[0:8])
        df_event['Occurrences'] = df_event['EventTemplate'].map(occ_dict)
        
        # as csv
        logging.info('Saving templates.csv...')   
        df_event.to_csv(os.path.join(self.savePath, self.logName + '_templates.csv'), index=False, columns=["EventId", "EventTemplate", "Occurrences"])

        # as pkl
        logging.info('Saving templates.pkl...') 
        df_event.to_pickle(os.path.join(self.savePath, self.logName + '_templates.pkl'))


    def printTree(self, node, dep):
        pStr = ''   
        for i in range(dep):
            pStr += '\t'

        if node.depth == 0:
            pStr += 'Root'
        elif node.depth == 1:
            pStr += '<' + str(node.digitOrtoken) + '>'
        else:
            pStr += node.digitOrtoken

        print(pStr)

        if node.depth == self.depth:
            return 1
        for child in node.childD:
            self.printTree(node.childD[child], dep+1)
    
    
        
        
    def parse(self, logName, is_training):
        logging.info('Parsing file: ' + os.path.join(self.path, logName))   

        start_time = datetime.now()
        self.logName = logName
        
        if is_training:
            self.rootNode = Node()
            self.logCluL = []

        self.load_data(is_training=is_training)

        #count = 0
        logging.info('Start to bulid the parser tree...')   
        with tqdm(total=len(self.df_log)) as pbar:
            for idx, line in self.df_log.iterrows():
                logID = line['LineId']
                
                logmessageL = self.preprocess(line['Content']).strip().split()
                # logmessageL = filter(lambda x: x != '', re.split('[\s=:,]', self.preprocess(line['Content'])))
                matchCluster = self.treeSearch(self.rootNode, logmessageL)

                #Match no existing log cluster
                if matchCluster is None:
                    newCluster = Logcluster(logTemplate=logmessageL, logIDL=[logID])
                    self.logCluL.append(newCluster)

                    logging.info('new Clust: {}'.format(newCluster.__dict__['logTemplate']))   

                    # check
                    #self.no_existing_raw_sample = line['Content']
                    #self.no_existing_pre_sample = logmessageL
                    #self.args1= self.rootNode
                    #self.args2= newCluster



                    self.addSeqToPrefixTree(self.rootNode, newCluster)

                #Add the new log message to the existing cluster
                else:
                    self.match_clust_sample = matchCluster
                    self.existing_pre_sample = logmessageL

                    newTemplate = self.getTemplate(logmessageL, matchCluster.logTemplate, is_training)
                    matchCluster.logIDL.append(logID)
                    if ' '.join(newTemplate) != ' '.join(matchCluster.logTemplate): 
                        matchCluster.logTemplate = newTemplate
                pbar.update(1)

            #count += 1
            #if count % 1000 == 0 or count == len(self.df_log):
            #    print('Processed {0:.1f}% of log lines.'.format(count * 100.0 / len(self.df_log)))

        # self.outputResult(self.logCluL)
        logging.info('Parsing done. [Time taken: {!s}]'.format(datetime.now() - start_time))   


        
        
    def load_data(self, is_training):
        headers, regex = self.generate_logformat_regex(self.log_format)
        self.df_log = self.log_to_dataframe(os.path.join(self.path, self.logName), regex, headers, self.log_format, is_training)

    def preprocess(self, line):
        for currentRex in self.rex:
        
            line = re.sub(currentRex, '<*>', line)
        
        return line

    def log_to_dataframe(self, log_file, regex, headers, logformat, is_training):
        """ Function to transform log file to dataframe 
        """
        log_messages = []
        # c_col = headers.index('Content')
        # d_col = headers.index('Date')
        # t_col = headers.index('Time')
        
        linecount = 0
        with open(log_file, 'r') as fin:
            logging.info('Loading and preprocessing the log messages...')   
            for line in tqdm(fin.readlines()):
                try:
                    for exp in self.p_list:
                        line = re.sub(exp[0], exp[1], line, count=1)
                    if line == '':
                        continue
                    match = regex.search(line.strip())
                    message = [match.group(header) for header in headers]
                    self.message = message
                    # '10.251.43.21:50010:Transmitted -> 10.251.43.21:50010: Transmitted
#                     ip_match = re.search(r'(/|)([0-9]+\.){3}[0-9]+(:[0-9]+|)(:|)', message[c_col])
#                     ip = message[c_col][ip_match.start():ip_match.end()]
#                     add_space = re.sub(ip, ip+' ', message[c_col])
#                     message[c_col] = re.sub(' +', ' ',add_space)

                    
                    # unixt = pd.to_datetime('-'.join([message[d_col], message[t_col]]), format="%y%m%d-%H%M%S")
                    # message = [m for i, m in enumerate(message) if i not in [d_col, t_col]]  

                    # message.append(unixt)

                    
                    log_messages.append(message)
                    linecount += 1
                except Exception as e:
                    pass
                
###########################################################################################################
        # headers = [h for i, h in enumerate(headers) if i not in [d_col, t_col]]  

        
        logdf = pd.DataFrame(log_messages, columns=headers)
        
        
        # logdf['diff'] = logdf['unixTime'].diff()
        # selVar = logdf.columns.tolist()[-2:]+ logdf.columns.tolist()[:-2]
        # logdf = logdf[selVar]

        
        ##
        
        logdf.insert(0, 'LineId', None)
        
        if is_training:
            logdf['LineId'] = [i + 1 for i in range(linecount)]
            self.infer_start = linecount
        else:
            logdf['LineId'] = [i + 1 for i in range(self.infer_start, self.infer_start+linecount)]
        return logdf


    def generate_logformat_regex(self, logformat):
        """ Function to generate regular expression to split log messages
        """
        headers = []
        splitters = re.split(r'(<[^<>]+>)', logformat)
        regex = ''
        for k in range(len(splitters)):
            if k % 2 == 0:
                splitter = re.sub(' +', '\\\s+', splitters[k])
                regex += splitter
            else:
                header = splitters[k].strip('<').strip('>')
                regex += '(?P<%s>.*?)' % header
                headers.append(header)
        regex = re.compile('^' + regex + '$')
        return headers, regex

    def get_parameter_list(self, row, is_training):
        # template_regex = re.sub(r"<.{1,5}>", "<*>", row["EventTemplate"])
        template_regex = row["EventTemplate"]

        # leave out examples which have no even <blk>
        # if "<*>" not in template_regex:
        #     logging.info(template_regex)
        #     return []
        
        # remove non-match params 
        if not is_training:
            s_temp = template_regex.split()
            s_cont = row["Content"].split()
            template_regex, re_content = self.params_checker(s_temp,s_cont)
        else:
            re_content = row["Content"]
            
        _template_regex = re.sub(r'([^A-Za-z0-9])', r'\\\1', template_regex)
        _template_regex = re.sub(r'\\ +', r'\\s+', _template_regex)
        _template_regex = "^" + _template_regex.replace("\<\*\>", "(.*?)") + "$"
        parameter_list = re.findall(_template_regex, re_content)
        parameter_list = parameter_list[0] if parameter_list else ()
        parameter_list = list(parameter_list) if isinstance(parameter_list, tuple) else [parameter_list]
        
        return template_regex, re_content, parameter_list
    
    
    def params_checker(self, s_temp, s_cont):
        assert len(s_temp) == len(s_cont)

        retVal_temp = []
        retVal_cont = []

        i = 0
        for word in s_temp:
            if word == s_cont[i]:
                retVal_temp.append(word)
                retVal_cont.append(s_cont[i])
            elif '<*>' in word:
                retVal_temp.append(word)
                retVal_cont.append(s_cont[i])

            else:
                pass
            i += 1
        return ' '.join(retVal_temp), ' '.join(retVal_cont)
